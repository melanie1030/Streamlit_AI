import os                 
import json               
import hashlib            
import re                 
import smtplib            
import secrets            
import glob               
from pathlib import Path  
from datetime import datetime, timedelta
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import streamlit as st
import pandas as pd
from PIL import Image
from sympy.polys.groebnertools import Num
import io
#User Authentication import
import assistant_system_01 as sys01  # 匯入系統1
import assistant_system_02 as sys02

# =============================================================================
# User Authentication
# =============================================================================

# =============================================================================
# --- 1. 初始設定與全域變數 (Initial Setup & Global Variables) ---
# =============================================================================
SCRIPT_DIR = Path(__file__).parent
USER_DATA_FILE = SCRIPT_DIR / "users.json"
STORAGE_BASE_PATH = SCRIPT_DIR / "user_files"

ALLOWED_EXTENSIONS = {
    ".jpg": "圖檔",
    ".jpeg": "圖檔",
    ".png": "圖檔",
    ".csv": "CSV資料夾",
    ".xlsx": "Excel資料",
    ".xls": "Excel資料"
}

def save_user_data(data, file_path):
    """將使用者資料儲存到 JSON 檔案。"""
    try:
        os.makedirs(os.path.dirname(file_path), exist_ok=True)
        with open(file_path, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=4, ensure_ascii=False)
        return True
    except IOError as e:
        st.error(f"錯誤：無法儲存使用者資料到 {file_path}。請檢查檔案權限。錯誤訊息: {e}")
        return False

def initialize_filesystem():
    """
    確保所有必要的資料夾和設定檔在程式啟動時就已存在。
    """
    os.makedirs(STORAGE_BASE_PATH, exist_ok=True)
    
    if not os.path.exists(USER_DATA_FILE):
        print(f"'{USER_DATA_FILE}' not found. Creating a new one with a default admin user.")
        default_users = {
            "admin": {
                "email": "admin@example.com",
                "password": hashlib.sha256("admin123".encode()).hexdigest(),
                "name": "Admin"
            }
        }
        save_user_data(default_users, USER_DATA_FILE)

initialize_filesystem()

# =============================================================================
# --- 2. 核心流程控制器 (Core Flow Controller) ---
# =============================================================================

def authentication_flow_controller(main_app_function=None):
    # 初始化 session 狀態
    if 'users_db' not in st.session_state:
        st.session_state.users_db = load_user_data(USER_DATA_FILE)
    if 'auth' not in st.session_state:
        st.session_state.auth = None
    if 'page_view' not in st.session_state:
        st.session_state.page_view = 'login'
    if 'df' not in st.session_state:  # 統一初始化，只執行一次
        st.session_state.df = None

    # 處理從 URL 來的密碼重設請求
    query_params = st.query_params
    page = query_params.get("page")
    if page == "reset_password":
        token = query_params.get("token")
        email = query_params.get("email")
        reset_password_ui(token, email)
        return

    # 根據登入狀態顯示不同內容
    if st.session_state.auth:
        show_main_app_wrapper(main_app_function)
    else:
        if st.session_state.page_view == 'login':
            login_ui()
        elif st.session_state.page_view == 'signup':
            sign_up_ui()
        elif st.session_state.page_view == 'forgot_password':
            forgot_password_ui()
        else:
            st.session_state.page_view = 'login'
            st.rerun()

def show_main_app_wrapper(main_app_function):
    """登入成功後的主應用程式容器。"""
    if main_app_function:
        main_app_function()

# =============================================================================
# --- 3. 使用者認證介面 (User Authentication UI) ---
# =============================================================================

def login_ui():
    """顯示登入介面。"""
    # 這裡應放置 set_background() 呼叫
    st.title("使用者登入系統")
    st.write("請使用您的帳號密碼登入")

    with st.form(key='login_form'):
        username = st.text_input('用戶名')
        password = st.text_input('密碼', type='password')
        
        if st.form_submit_button('登入'):
            users_db = st.session_state.users_db
            user_data = users_db.get(username)
            if user_data and hashlib.sha256(password.encode()).hexdigest() == user_data['password']:
                st.session_state.auth = True
                st.session_state.username = username
                st.rerun()
            else:
                st.error('用戶名或密碼錯誤')
    
    st.markdown("---")
    col1, col2 = st.columns(2)
    with col1:
        if st.button('註冊新帳號'):
            st.session_state.page_view = 'signup'
            st.rerun()
    with col2:
        if st.button('忘記密碼?'):
            st.session_state.page_view = 'forgot_password'
            st.rerun()

def sign_up_ui():
    """顯示註冊表單的介面。"""
    # 這裡應放置 set_background() 呼叫
    st.title("使用者登入系統")
    with st.form(key='signup', clear_on_submit=True):
        st.subheader('註冊新帳號')
        email = st.text_input('電子郵件')
        username = st.text_input('用戶名 (可使用中文)')
        password = st.text_input('密碼', type='password', placeholder='至少4位')
        password2 = st.text_input('確認密碼', type='password')

        if st.form_submit_button('註冊'):
            users_db = st.session_state.users_db
            error = None
            if not validate_email(email): error = "電子郵件格式錯誤"
            elif email in get_existing_emails(users_db): error = "電子郵件已註冊"
            elif not username: error = "請輸入用戶名"
            elif not validate_username(username): error = "用戶名含非法字元"
            elif username in get_existing_usernames(users_db): error = "用戶名已存在"
            elif len(password) < 4: error = "密碼長度不足"
            elif password != password2: error = "密碼不一致"

            if error:
                st.warning(error)
            else:
                hashed_pw = hashlib.sha256(password.encode()).hexdigest()
                users_db[username] = {'email': email, 'password': hashed_pw, 'name': username}
                save_user_data(users_db, USER_DATA_FILE)
                st.success('註冊成功！請返回登入頁面。')
                st.session_state.page_view = 'login'
                st.rerun()
    
    if st.button("返回登入"):
        st.session_state.page_view = 'login'
        st.rerun()

def forgot_password_ui():
    """顯示「忘記密碼」的介面。"""
    st.title("使用者登入系統")
    with st.form(key='forgot_password_form'):
        st.subheader("重設密碼")
        email = st.text_input("請輸入您註冊的電子郵件地址")
        
        if st.form_submit_button("發送重置連結"):
            users_db = st.session_state.users_db
            user_to_reset = next(((username, data) for username, data in users_db.items() if data.get('email') == email), None)

            if user_to_reset:
                username_to_reset, _ = user_to_reset
                token = secrets.token_urlsafe(32)
                expiry = datetime.now() + timedelta(minutes=5)
                
                users_db[username_to_reset]['reset_token'] = token
                users_db[username_to_reset]['reset_token_expiry'] = expiry.isoformat()
                save_user_data(users_db, USER_DATA_FILE)

                # 請在 Streamlit Secrets 中設定 BASE_URL
                base_url = st.secrets.get("BASE_URL", "http://localhost:8501") 
                reset_link = f"{base_url}/?page=reset_password&token={token}&email={email}"
                
                if send_reset_email(email, reset_link):
                    st.success("重置連結已發送到您的電子郵件，請在5分鐘內點擊連結。")
            else:
                st.warning("找不到與此電子郵件關聯的帳戶。")
    
    if st.button("返回登入"):
        st.session_state.page_view = 'login'
        st.rerun()

def reset_password_ui(token, email):
    """顯示「設定新密碼」的介面。"""
    st.title("使用者登入系統")
    st.subheader("設定您的新密碼")
    users_db = st.session_state.users_db
    user_to_reset = next(((username, data) for username, data in users_db.items() if data.get('email') == email), None)

    if not user_to_reset:
        st.error("無效的請求。")
        return

    username_to_reset, user_data = user_to_reset
    stored_token = user_data.get('reset_token')
    token_expiry_str = user_data.get('reset_token_expiry')

    if not stored_token or stored_token != token or not token_expiry_str or datetime.now() > datetime.fromisoformat(token_expiry_str):
        st.error("無效或已過期的重置連結。請重新申請。")
        if 'reset_token' in users_db[username_to_reset]:
            del users_db[username_to_reset]['reset_token']
            del users_db[username_to_reset]['reset_token_expiry']
            save_user_data(users_db, USER_DATA_FILE)
        return

    with st.form(key='reset_password_form'):
        new_password = st.text_input("新密碼", type="password", placeholder="至少4位")
        confirm_password = st.text_input("確認新密碼", type="password")

        if st.form_submit_button("更新密碼"):
            if len(new_password) < 4:
                st.warning("密碼長度不足")
            elif new_password != confirm_password:
                st.warning("密碼不一致")
            else:
                hashed_pw = hashlib.sha256(new_password.encode()).hexdigest()
                users_db[username_to_reset]['password'] = hashed_pw
                if 'reset_token' in users_db[username_to_reset]:
                    del users_db[username_to_reset]['reset_token']
                    del users_db[username_to_reset]['reset_token_expiry']
                save_user_data(users_db, USER_DATA_FILE)
                st.success("密碼更新成功！您現在可以使用新密碼登入。")
                st.info("為了安全起見，請關閉此頁面並返回主頁登入。")

# =============================================================================
# --- 4. 檔案管理功能 (File Management Functions) ---
# =============================================================================

class MockUploadedFile:
    """模擬 Streamlit UploadedFile，支援 read(size)、getvalue() 等"""
    def __init__(self, name, content):
        self.name = name
        self.type = 'text/csv' if name.endswith('.csv') else 'text/plain' if name.endswith('.txt') else 'application/octet-stream'
        self.size = len(content)
        self.content = io.BytesIO(content)
    
    def getvalue(self):
        return self.content.getvalue()
    
    def read(self, size=-1):
        return self.content.read(size)
    
    def seek(self, offset):
        self.content.seek(offset)

def handle_file_upload(uploaded_file, username: str):
    if uploaded_file is None:
        st.warning("請先選擇要上傳的檔案。")
        return

    file_name = uploaded_file.name
    file_extension = os.path.splitext(file_name)[1].lower()

    if file_extension not in ALLOWED_EXTENSIONS:
        st.error(f"錯誤：不支援的檔案格式 '{file_extension}'。")
        st.info(f"僅支援以下格式：{', '.join(ALLOWED_EXTENSIONS.keys())}")
        return

    sub_folder = ALLOWED_EXTENSIONS[file_extension]

    target_dir = Path(STORAGE_BASE_PATH) / username / sub_folder
    file_path = target_dir / file_name

    if file_path.exists():
        st.warning(f"檔案 '{file_name}' 已存在於 '{sub_folder}' 資料夾中，請更換檔名或刪除舊檔。")
        return

    try:
        file_data = uploaded_file.getvalue()
        if _write_file_and_log(str(file_path), file_data, username):
            st.success(f"檔案 '{file_name}' 已成功上傳至 '{sub_folder}' 資料夾！")
            st.balloons()
            st.rerun() 
    except Exception as e:
        st.error(f"讀取上傳檔案時發生錯誤: {e}")

def handle_delete_request(file_path_to_delete: str, username: str):
    """安全地刪除指定的檔案，並記錄日誌。"""
    try:
        base_dir = Path(STORAGE_BASE_PATH).resolve()
        file_path = Path(file_path_to_delete).resolve()

        if not file_path.is_relative_to(base_dir / username):
            st.error("錯誤：無效的檔案路徑，禁止刪除。")
            return False

        if file_path.exists() and file_path.is_file():
            os.remove(file_path)
            
            timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            log_message = f"[{timestamp}] User '{username}' deleted file '{file_path_to_delete}'\n"
            log_dir = Path(STORAGE_BASE_PATH) / "system_logs"
            os.makedirs(log_dir, exist_ok=True)
            with open(log_dir / "delete_log.txt", "a", encoding="utf-8") as log_file:
                log_file.write(log_message)
            
            st.success(f"檔案 '{file_path.name}' 已成功刪除。")
            return True
        else:
            st.warning("檔案不存在或無法刪除。")
            return False
    except Exception as e:
        st.error(f"刪除檔案時發生錯誤: {e}")
        return False

def get_saved_files(username: str) -> dict:
    """掃描並取得使用者所有子資料夾中的檔案，並按資料夾分類。"""
    user_dir = Path(STORAGE_BASE_PATH) / username
    if not user_dir.exists():
        return {}
    
    # 掃描所有子資料夾中的所有檔案
    all_files = [p for p in user_dir.rglob("*") if p.is_file() and "system_logs" not in p.parts]
    
    categorized_files = {}
    for file_path in all_files:
        category = file_path.parent.name
        if category not in categorized_files:
            categorized_files[category] = []
        categorized_files[category].append(str(file_path))
        
    return categorized_files

def confirm_and_overwrite(username: str):
    """執行覆蓋儲存的操作。"""
    file_path = st.session_state.pop('confirm_overwrite_path', None)
    data_to_save = st.session_state.pop('data_to_save', None)
    if file_path and data_to_save:
        if _write_file_and_log(file_path, data_to_save, username):
            st.success("檔案已成功覆蓋！")
            st.balloons()
    st.rerun()

def cancel_overwrite():
    """取消覆蓋操作。"""
    st.session_state.pop('confirm_overwrite_path', None)
    st.session_state.pop('data_to_save', None)
    st.rerun()

# =============================================================================
# --- 5. 後端輔助函式 (Backend Helper Functions) ---
# =============================================================================

def load_user_data(file_path):
    """從 JSON 檔案載入使用者資料。"""
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return {
            "admin": {
                "email": "admin@example.com",
                "password": hashlib.sha256("admin123".encode()).hexdigest(),
                "name": "Admin"
            }
        }

def save_user_data(data, file_path):
    """將使用者資料儲存到 JSON 檔案。"""
    try:
        os.makedirs(os.path.dirname(file_path), exist_ok=True)
        with open(file_path, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=4, ensure_ascii=False)
    except IOError:
        st.error(f"錯誤：無法儲存使用者資料到 {file_path}")

# --- 驗證與資料查詢 ---
def validate_email(email):
    """驗證電子郵件格式。"""
    pattern = re.compile(r"^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$")
    return pattern.match(email)

def validate_username(username):
    """驗證使用者名稱格式（允許中英數）。"""
    return re.match(r"^[a-zA-Z0-9\u4e00-\u9fa5]*$", username)

def get_existing_emails(users_db):
    """取得所有已註冊的電子郵件列表。"""
    return [user['email'] for user in users_db.values()]

def get_existing_usernames(users_db):
    """取得所有已註冊的使用者名稱列表。"""
    return list(users_db.keys())

# --- 郵件服務 ---
def send_reset_email(recipient_email, reset_link):
    """發送密碼重設郵件。"""
    try:
        creds = st.secrets["email_credentials"]
        sender_email = creds["sender_email"]
        sender_password = creds["sender_password"]
        smtp_server = creds["smtp_server"]
        smtp_port = creds["smtp_port"]

        msg = MIMEMultipart()
        msg['From'] = f"NUTC_AI <{sender_email}>"
        msg['To'] = recipient_email
        msg['Subject'] = "密碼重置請求"
        body = f"""
        <html><body>
        <p>您好：</p>
        <p>我們收到了您的密碼重設請求。請點擊下方按鈕來設定您的新密碼。</p>
        <p>此連結將在 <strong>5 分鐘</strong>後失效。</p>
        <a href="{reset_link}" style="background-color: #007bff; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;">重設密碼</a>
        <p>如果您沒有提出此請求，請忽略此郵件。</p>
        </body></html>
        """
        msg.attach(MIMEText(body, 'html'))

        with smtplib.SMTP(smtp_server, smtp_port) as server:
            server.starttls()
            server.login(sender_email, sender_password)
            server.send_message(msg)
        return True
    except Exception as e:
        st.error(f"郵件發送失敗: {e}")
        return False
# =============================================================================
# User Authentication end
# =============================================================================

def _write_file_and_log(file_path: str, data: bytes, username: str):
    """將 byte 資料寫入檔案並記錄日誌。"""
    try:
        os.makedirs(os.path.dirname(file_path), exist_ok=True)
        with open(file_path, "wb") as f:
            f.write(data)
        
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        log_message = f"[{timestamp}] User '{username}' saved file to '{file_path}'\n"
        log_dir = Path(STORAGE_BASE_PATH) / "system_logs"
        os.makedirs(log_dir, exist_ok=True)
        with open(log_dir / "save_log.txt", "a", encoding="utf-8") as log_file:
            log_file.write(log_message)
        return True
    except Exception as e:
        st.error(f"寫入檔案時發生錯誤: {e}")
        return False


def main_ui():
    if 'view' not in st.session_state:
        st.session_state.view = 'main'
    username = st.session_state.get("username", "Guest")

    if st.session_state.view == 'file_management':
        with st.sidebar:
            st.subheader(f"你好, {username}")
            if st.button("登出"):
                for key in list(st.session_state.keys()):
                    del st.session_state[key]
                st.rerun()
            st.markdown("---")
            if st.button("⬅️ 返回主頁"):
                st.session_state.view = 'main'
                st.rerun()
            st.markdown("---")
            # === 新增：系統切換按鈕 ===
            if st.button("進入系統 1 (Gemini 多功能 AI 助理) 🚀", use_container_width=True):
                st.session_state.view = 'system_01'
                st.rerun()
            if st.button("進入系統 2 (銷貨損益分析小幫手) 📊", use_container_width=True):
                st.session_state.view = 'system_02'
                st.rerun()

        st.title("使用者管理 📂")

        st.header("📤 檔案上傳")
        allowed_types = [ext.lstrip('.') for ext in ALLOWED_EXTENSIONS.keys()]
        uploaded_file = st.file_uploader("選擇檔案", type=allowed_types)
        if st.button("上傳檔案"):
            handle_file_upload(uploaded_file, username)
        
        st.markdown("---")

        st.header("📊 分析項目")
        if 'analyzing_file' in st.session_state:
            file_name = st.session_state.analyzing_file
            if 'df' in st.session_state:
                st.info(f"**資料集:**\n{file_name}")
                try:
                    if isinstance(st.session_state.df, bytes):

                        encodings = ['utf-8', 'gbk', 'big5']  # 嘗試多種編碼
                        df = None
                        for encoding in encodings:
                            try:
                                if file_name.endswith('.csv'):
                                    df = pd.read_csv(io.BytesIO(st.session_state.df), encoding=encoding)
                                elif file_name.endswith(('.xlsx', '.xls')):
                                    df = pd.read_excel(io.BytesIO(st.session_state.df))
                                break  # 成功解析則退出循環
                            except UnicodeDecodeError:
                                continue
                        if df is None:
                            st.error(f"無法解析 '{file_name}'，支援的編碼 ({', '.join(encodings)}) 均失敗")
                        else:
                            st.session_state.current_dataframe = df  # 同步到系統二使用的變數
                    else:
                        df = st.session_state.df
                    if df is not None:
                        st.dataframe(df.head())
                except Exception as e:
                    st.error(f"無法顯示資料集 '{file_name}'：{str(e)}")
            elif 'pic' in st.session_state:
                st.info(f"**圖片:**\n{file_name}")
                st.image(st.session_state.pic, use_column_width=True)
            if st.button("移除分析", use_container_width=True):
                del st.session_state.analyzing_file
                if 'df' in st.session_state: del st.session_state.df
                if 'pic' in st.session_state: del st.session_state.pic
                st.rerun()
        else:
            st.write("尚未加入任何分析項目。")
        st.markdown("---")

        st.header("🗂️ 已儲存的檔案")
        saved_files_by_category = get_saved_files(username)

        if not saved_files_by_category:
            st.info("您尚未上傳任何檔案。")
        else:
            def _add_to_analysis(file_path_str):
                """將檔案注入分析，支援 system_01 的 RAG 和 system_02 的 CSV/圖片"""
                file_path = Path(file_path_str)
                file_extension = file_path.suffix.lower()
                
                try:
                    if 'analyzing_file' in st.session_state:
                        del st.session_state.analyzing_file
                    if 'df' in st.session_state:
                        del st.session_state.df
                    if 'pic' in st.session_state:
                        del st.session_state.pic
                    if 'retriever_chain' in st.session_state:
                        del st.session_state.retriever_chain
                    
                    # 讀取檔案內容
                    with open(file_path, 'rb') as f:
                        file_bytes = f.read()
                    
                    # 處理 CSV/Excel
                    if file_extension in ['.csv', '.xlsx', '.xls']:
                        encodings = ['utf-8', 'gbk', 'big5']
                        df = None
                        for encoding in encodings:
                            try:
                                if file_extension == '.csv':
                                    df = pd.read_csv(io.BytesIO(file_bytes), encoding=encoding)
                                elif file_extension in ['.xlsx', '.xls']:
                                    df = pd.read_excel(io.BytesIO(file_bytes))
                                break
                            except UnicodeDecodeError:
                                continue
                        if df is None:
                            st.error(f"無法解析 '{file_path.name}'，支援的編碼 ({', '.join(encodings)}) 均失敗")
                            return
                        
                        # 轉 UTF-8 CSV bytes (用於模擬上傳)
                        csv_bytes = df.to_csv(index=False, encoding='utf-8').encode('utf-8')
                        
                        # 模擬 sys01 上傳
                        st.session_state.df = csv_bytes  # 存 bytes
                        if st.session_state.get('use_rag', False):
                            openai_api_key = st.session_state.get("openai_api_key_input") or os.environ.get("OPENAI_API_KEY")
                            if not openai_api_key:
                                st.error("RAG 功能已啟用，請在上方輸入您的 OpenAI API Key！")
                            else:
                                try:
                                    st.session_state.retriever_chain = sys01.create_lc_retriever(csv_bytes, openai_api_key)
                                    st.toast(f"RAG 知識庫已為 '{file_path.name}' 建立！")
                                except Exception as e:
                                    st.error(f"建立 RAG 知識庫失敗: {str(e)}")
                                    import traceback
                                    st.write(f"Traceback: {traceback.format_exc()}")
                                    return
                        
                        # 模擬注入到 system_02 (保留原有)
                        try:
                            uploaded_csv_file = MockUploadedFile(name=file_path.name, content=csv_bytes)
                            
                            uploaded_desc_file = None
                            desc_file_path = file_path.with_suffix('.txt')
                            if desc_file_path.exists():
                                with open(desc_file_path, 'rb') as f:
                                    desc_bytes = f.read()
                                uploaded_desc_file = MockUploadedFile(name=desc_file_path.name, content=desc_bytes)
                                st.toast(f"找到描述檔案 {desc_file_path.name}，已加入分析！")
                            else:
                                st.toast(f"未找到描述檔案 {desc_file_path.name}。")
                            
                            sys02.load_csv_and_get_summary(uploaded_csv_file, uploaded_desc_file)
                            st.toast(f"已將 {file_path.name} 注入 system_02 分析！")
                            
                            st.session_state.current_dataframe = df  # 同步到 system_02
                        except Exception as e:
                            st.error(f"注入 system_02 失敗: {str(e)}")
                            return
                    
                    # 處理圖片 (保留)
                    elif file_extension in ['.png', '.jpg', '.jpeg']:
                        st.session_state.pic = Image.open(io.BytesIO(file_bytes))
                        st.toast(f"已將 {file_path.name} 加入分析！")
                    
                    st.session_state.analyzing_file = file_path.name
                
                except Exception as e:
                    st.error(f"Debug Error: {str(e)}")
                    import traceback
                    st.write(f"Traceback: {traceback.format_exc()}")

            for category, files in saved_files_by_category.items():
                with st.expander(f"📁 {category} ({len(files)} 個檔案)", expanded=True):
                    for file_path_str in files:
                        file_path = Path(file_path_str)
                        
                        col1, col2, col3, col4 = st.columns([0.5, 0.18, 0.14, 0.18])
                        
                        with col1:
                            st.write(file_path.name)
                        
                        with col2:
                            st.button(
                                "加入分析", 
                                key=f"analyze_{file_path_str}", 
                                use_container_width=True,
                                on_click=_add_to_analysis,
                                args=(file_path_str,)
                            )
                            
                        with col3:
                            def _set_file_to_delete(path):
                                st.session_state.file_to_delete = path
                            st.button(
                                "刪除", 
                                key=f"del_{file_path_str}", 
                                use_container_width=True,
                                on_click=_set_file_to_delete,
                                args=(file_path_str,)
                            )
                        
                        with col4:
                            try:
                                with open(file_path, "rb") as f:
                                    st.download_button(
                                        label="下載檔案",
                                        data=f,
                                        file_name=file_path.name,
                                        key=f"download_{file_path_str}",
                                        use_container_width=True
                                    )
                            except FileNotFoundError:
                                st.error("檔案遺失")

        if 'file_to_delete' in st.session_state:
            file_to_delete = st.session_state.file_to_delete
            file_name_to_delete = Path(file_to_delete).name

            @st.dialog(f"確認刪除檔案")
            def show_confirm_dialog():
                st.warning(f"您確定要永久刪除檔案 '{file_name_to_delete}' 嗎？")
                st.write("此操作無法復原。")
                
                col1, col2 = st.columns(2)
                with col1:
                    if st.button("確認刪除", use_container_width=True, type="primary"):
                        handle_delete_request(file_to_delete, username)
                        del st.session_state.file_to_delete
                        st.rerun()
                with col2:
                    if st.button("取消", use_container_width=True):
                        del st.session_state.file_to_delete
                        st.rerun()

            show_confirm_dialog()
    # === 新增：系統1和系統2頁面 ===
    elif st.session_state.view == 'system_01':
        sys01.main()  # 呼叫系統1，st.session_state.df 已共享
    elif st.session_state.view == 'system_02':
        sys02.run_system_02()  # 呼叫系統2，st.session_state.df 已共享
    else:
        with st.sidebar:
            st.subheader(f"你好, {username}")
            if st.button("登出", key="logout_main"):
                for key in list(st.session_state.keys()):
                    del st.session_state[key]
                st.rerun()
            if st.button("使用者管理 📂", use_container_width=True):
                st.session_state.view = 'file_management'
                st.rerun()
            st.markdown("---")
            # === 新增：系統切換按鈕 ===
            if st.button("Gemini 多功能 AI 助理", use_container_width=True):
                st.session_state.view = 'system_01'
                st.rerun()
            if st.button("銷貨損益分析小幫手", use_container_width=True):
                st.session_state.view = 'system_02'
                st.rerun()
        st.title("歡迎使用系統")
        st.write("請從側邊欄選擇功能：檔案管理、系統1 或 系統2。")



#主程式
if __name__ == "__main__":
    authentication_flow_controller(main_app_function=main_ui)